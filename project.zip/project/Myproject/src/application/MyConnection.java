package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyConnection {
	
	public Connection getConnection()  throws SQLException, ClassNotFoundException
	{
		
			
		Class.forName("com.mysql.jdbc.Driver");
		Connection  con=DriverManager.getConnection("jdbc:mysql://localhost:3306/farmer", "root","rajan@1551" );
	    System.out.println("DB Connected");
		return con;
	}

	
	}
		
		
		
	
