package application;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class registercontrol {
	
	// farmer register data==================================
		private TextField fname,lname,fmobile,aadhar,bdate,fpassword,gender;
		private Button fsignup;
		// farmer registration======================================================.
		
		
}

