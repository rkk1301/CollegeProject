package application;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;



import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;

public class HomePageController implements Initializable{
	@FXML
	private Pane p_farmer,p_Scientist,p_bank,p_admin,p_about,f_welcome,p_contact,p_home,p_login,p_fnregister,p_f_login,p_apply_loan,p_registersuccess;
	@FXML
	private Button bt_farmer,bt_scientist,bt_bank,bt_admin,bt_about,bt_contact,bt_home,flogin,bt_newApp,bt_f_login,p_Apply_loan,bt_flogin,fsignup;
	
	
	@FXML
	private Pane sappli,b_Dashboard,admindash;
	
	@FXML
	private Button sapply,joinus,slogin,b_signin,admin;
	@FXML
	private Pane rootpane,sdashboard;
	
	
	
	
	
	

	@FXML
	private void HandleButtonAction(ActionEvent event) throws ClassNotFoundException, SQLException
	{
		

	
		if(event.getSource()==bt_home)
		{
			p_home.toFront();
		}
		if(event.getSource()==fsignup)
		{
			p_registersuccess.toFront();
		}
		if(event.getSource()==bt_farmer)
		{
			p_farmer.toFront();
			
		}
		if(event.getSource()==bt_flogin)
		{
			f_welcome.toFront();
		}
		if(event.getSource()==bt_newApp)
		{
			p_apply_loan.toFront();
		}
		
		
		if(event.getSource()==joinus)
		{
			sappli.toFront();
		}

		
		if(event.getSource()==b_signin)
		{
			b_Dashboard.toFront();
		}
		if(event.getSource()==slogin)
		{
			sdashboard.toFront();
		}

		if(event.getSource()==admin)
		{
			admindash.toFront();
		}

		
				
		else if(event.getSource()==flogin)
		{
			p_login.toFront();
		}
		else
			if(event.getSource()==bt_scientist)
			{
				p_Scientist.toFront();
			}
			else
				if(event.getSource()==bt_bank)
				{
					p_bank.toFront();
				}
				else
					if(event.getSource()==bt_admin)
					{
						p_admin.toFront();
					}
					else
						if(event.getSource()==bt_about)
						{
							p_about.toFront();
						}
						else
							if(event.getSource()==bt_contact)
							{
								p_contact.toFront();
							}
	}
	

	@Override
	public void initialize(URL url, ResourceBundle dashc) {
		// TODO Auto-generated method stub
		
	}
	
	
}
